function WalkQLearning(s)
